<?php

namespace EightyNine\Approvals;

class Approval
{
}
