<?php

namespace EightyNine\Approvals\Traits;

trait HasApprovalWidget
{

}
