<?php

namespace EightyNine\Approvals\Forms;

class ApprovalActions
{

}
