<?php

namespace EightyNine\Approvals\Testing;

use Livewire\Features\SupportTesting\Testable;

/**
 * @mixin Testable
 */
class TestsApproval
{
    //
}
